package br.com.adailsonteck.tv

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.net.URLEncoder
import java.util.concurrent.Executors

private const val BG = 0xFF080F1E.toInt()
private const val PANEL = 0xFF111D31.toInt()
private const val PANEL_2 = 0xFF17263D.toInt()
private const val ACCENT = 0xFF18A8E0.toInt()
private const val MUTED = 0xFF9EADC3.toInt()
private const val DEFAULT_M3U_URL = "https://raw.githubusercontent.com/BuddyChewChew/pluto/refs/heads/main/pluto_br.m3u"

 data class Channel(val name: String, val url: String, val group: String = "Canais")

class MainActivity : Activity() {
    private val client = OkHttpClient()
    private val io = Executors.newSingleThreadExecutor()
    private val channels = mutableListOf<Channel>()
    private var visibleChannels = listOf<Channel>()
    private lateinit var list: ListView
    private lateinit var status: TextView
    private lateinit var playerView: PlayerView
    private lateinit var search: EditText
    private lateinit var categoryBar: LinearLayout
    private lateinit var loginPanel: LinearLayout
    private var player: ExoPlayer? = null
    private var selectedGroup = "Todos"

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int = 12, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }
    private fun label(s: String, size: Float = 14f, color: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun field(hintText: String, password: Boolean = false) = EditText(this).apply {
        hint = hintText; setSingleLine(true); textSize = 14f
        setTextColor(Color.WHITE); setHintTextColor(MUTED)
        setPadding(dp(14), dp(11), dp(14), dp(11))
        background = rounded(PANEL_2, 9)
        if (password) inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
    }
    private fun actionButton(textValue: String, primary: Boolean = true, action: () -> Unit) = TextView(this).apply {
        text = textValue; textSize = 14f; gravity = Gravity.CENTER; setTypeface(typeface, Typeface.BOLD)
        setTextColor(Color.WHITE); setPadding(dp(16), dp(13), dp(16), dp(13))
        background = rounded(if (primary) ACCENT else PANEL_2, 9)
        setOnClickListener { action() }
    }
    private fun addGap(parent: LinearLayout, height: Int = 8) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        window.decorView.systemUiVisibility = 0

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
        }
        val scroll = ScrollView(this).apply { isFillViewport = true; isVerticalScrollBarEnabled = false }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(22))
        }
        scroll.addView(page)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        // Header inspired by modern IPTV/streaming apps, with original ADAILSON TECK branding.
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brandBlock = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brandBlock.addView(label("ADAILSON TECK", 23f, Color.WHITE, true))
        brandBlock.addView(label("SEU ENTRETENIMENTO", 10f, MUTED, true))
        header.addView(brandBlock, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(label("●", 17f, ACCENT, true))
        page.addView(header)
        addGap(page, 18)

        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(PANEL, 10)
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        val liveTab = actionButton("TV AO VIVO", true) { showTabMessage("TV AO VIVO") }
        val moviesTab = actionButton("FILMES", false) { toast("O catálogo de filmes será ativado quando houver uma fonte VOD configurada.") }
        val seriesTab = actionButton("SÉRIES", false) { toast("O catálogo de séries será ativado quando houver uma fonte VOD configurada.") }
        tabs.addView(liveTab, LinearLayout.LayoutParams(0, -2, 1f))
        tabs.addView(moviesTab, LinearLayout.LayoutParams(0, -2, 0.78f).apply { leftMargin = dp(4) })
        tabs.addView(seriesTab, LinearLayout.LayoutParams(0, -2, 0.78f).apply { leftMargin = dp(4) })
        page.addView(tabs)
        addGap(page, 14)

        // Lista M3U padrão integrada: sem campos de conexão ou opções Xtream.
        page.addView(label("CANAIS CARREGADOS AUTOMATICAMENTE", 12f, MUTED, true))
        addGap(page, 16)

        page.addView(label("ASSISTINDO AGORA", 15f, Color.WHITE, true))
        addGap(page, 8)
        playerView = PlayerView(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, dp(205))
            setBackgroundColor(Color.BLACK)
            useController = true
            controllerShowTimeoutMs = 3500
            background = rounded(Color.BLACK, 12)
        }
        page.addView(playerView)
        addGap(page, 12)

        status = label("Carregando lista de canais...", 12f, MUTED)
        page.addView(status)
        addGap(page, 10)
        page.addView(label("CANAIS", 16f, Color.WHITE, true))
        addGap(page, 8)
        search = field("Buscar canal...")
        page.addView(search)
        addGap(page, 8)
        categoryBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val categoryScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(categoryBar)
        }
        page.addView(categoryScroll)
        addGap(page, 8)

        list = ListView(this).apply {
            divider = null
            isNestedScrollingEnabled = true
            setBackgroundColor(BG)
            layoutParams = LinearLayout.LayoutParams(-1, dp(340))
        }
        page.addView(list)
        list.setOnItemClickListener { _, _, position, _ ->
            if (position in visibleChannels.indices) play(visibleChannels[position])
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { filterChannels() }
            override fun afterTextChanged(s: Editable?) {}
        })
        setContentView(root)
        restoreSavedChannels()
        loadM3u(DEFAULT_M3U_URL)
    }

    private fun showTabMessage(tab: String) { status.text = "$tab selecionado" }

    private fun loadM3u(url: String) {
        status.text = "Carregando lista M3U..."
        io.execute {
            try {
                val req = Request.Builder().url(url).build()
                client.newCall(req).execute().use { response ->
                    if (!response.isSuccessful) error("HTTP ${response.code}")
                    val body = response.body?.string() ?: error("Lista vazia")
                    val parsed = parseM3u(body)
                    runOnUiThread { showChannels(parsed, "M3U") }
                }
            } catch (e: Exception) { runOnUiThread { status.text = "Erro ao carregar M3U: ${e.message}" } }
        }
    }

    private fun parseM3u(text: String): List<Channel> {
        val out = mutableListOf<Channel>()
        var name = "Canal"; var group = "Canais"
        text.lineSequence().forEach { raw ->
            val line = raw.trim()
            if (line.startsWith("#EXTINF", true)) {
                name = line.substringAfterLast(",").trim().ifBlank { "Canal" }
                group = Regex("""group-title="([^"]*)"""").find(line)?.groupValues?.get(1) ?: "Canais"
            } else if (line.isNotBlank() && !line.startsWith("#") &&
                (line.startsWith("http://") || line.startsWith("https://"))) out.add(Channel(name, line, group))
        }
        return out
    }

    private fun loadXtream(server: String, username: String, password: String) {
        status.text = "Consultando canais Xtream..."
        io.execute {
            try {
                val u = URLEncoder.encode(username, "UTF-8")
                val p = URLEncoder.encode(password, "UTF-8")
                val url = "$server/player_api.php?username=$u&password=$p&action=get_live_streams"
                val req = Request.Builder().url(url).build()
                client.newCall(req).execute().use { response ->
                    if (!response.isSuccessful) error("HTTP ${response.code}")
                    val arr = JSONArray(response.body?.string() ?: "[]")
                    val parsed = mutableListOf<Channel>()
                    for (i in 0 until arr.length()) {
                        val item = arr.getJSONObject(i)
                        val id = item.optString("stream_id")
                        val title = item.optString("name", "Canal")
                        val ext = item.optString("container_extension", "ts").ifBlank { "ts" }
                        val cat = item.optString("category_name", "TV ao vivo")
                        parsed.add(Channel(title, "$server/live/$username/$password/$id.$ext", cat))
                    }
                    runOnUiThread { showChannels(parsed, "Xtream") }
                }
            } catch (e: Exception) { runOnUiThread { status.text = "Erro Xtream: ${e.message}" } }
        }
    }

    private fun showChannels(items: List<Channel>, source: String) {
        channels.clear(); channels.addAll(items)
        saveChannels(items)

        selectedGroup = "Todos"
        status.text = "$source • ${items.size} canais carregados"
        buildCategories()
        filterChannels()
    }


    // Guarda a lista carregada no armazenamento privado do aplicativo.
    // Assim os canais continuam disponíveis quando o app for fechado e aberto novamente.
    private fun saveChannels(items: List<Channel>) {
        try {
            val array = JSONArray()
            items.forEach { channel ->
                val obj = org.json.JSONObject()
                obj.put("name", channel.name)
                obj.put("url", channel.url)
                obj.put("group", channel.group)
                array.put(obj)
            }
            openFileOutput("saved_channels.json", MODE_PRIVATE).use { output ->
                output.write(array.toString().toByteArray(Charsets.UTF_8))
            }
        } catch (e: Exception) {
            if (::status.isInitialized) status.text = "Lista carregada, mas não foi possível salvar: ${e.message}"
        }
    }

    private fun restoreSavedChannels() {
        try {
            val file = getFileStreamPath("saved_channels.json")
            if (!file.exists()) return
            val content = openFileInput("saved_channels.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
            val array = JSONArray(content)
            val restored = mutableListOf<Channel>()
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                val name = item.optString("name")
                val url = item.optString("url")
                val group = item.optString("group", "Canais")
                if (name.isNotBlank() && url.isNotBlank()) restored.add(Channel(name, url, group))
            }
            if (restored.isNotEmpty()) showChannels(restored, "Lista salva")
        } catch (e: Exception) {
            status.text = "Não foi possível recuperar a lista salva: ${e.message}"
        }
    }

    private fun buildCategories() {
        categoryBar.removeAllViews()
        val groups = listOf("Todos") + channels.map { it.group }.distinct().filter { it.isNotBlank() }.sorted()
        groups.forEach { group ->
            val chip = TextView(this).apply {
                text = group; textSize = 12f; setTextColor(Color.WHITE)
                setPadding(dp(14), dp(9), dp(14), dp(9))
                background = rounded(if (group == selectedGroup) ACCENT else PANEL_2, 18)
                setOnClickListener { selectedGroup = group; buildCategories(); filterChannels() }
            }
            val lp = LinearLayout.LayoutParams(-2, -2); lp.rightMargin = dp(7)
            categoryBar.addView(chip, lp)
        }
    }

    private fun filterChannels() {
        val query = if (::search.isInitialized) search.text.toString().trim() else ""
        visibleChannels = channels.filter {
            (selectedGroup == "Todos" || it.group == selectedGroup) &&
                (query.isBlank() || it.name.contains(query, true))
        }
        if (!::list.isInitialized) return
        list.adapter = object : ArrayAdapter<Channel>(this, android.R.layout.simple_list_item_1, visibleChannels) {
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
                val item = getItem(position) ?: return TextView(this@MainActivity)
                val row = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(10), dp(9), dp(10), dp(9))
                    background = rounded(PANEL, 9)
                }
                val logo = TextView(this@MainActivity).apply {
                    text = "▶"; gravity = Gravity.CENTER; textSize = 17f; setTextColor(ACCENT)
                    background = rounded(PANEL_2, 9)
                }
                row.addView(logo, LinearLayout.LayoutParams(dp(42), dp(42)))
                val texts = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
                texts.addView(label(item.name, 14f, Color.WHITE, true))
                texts.addView(label(item.group, 11f, MUTED))
                row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
                row.addView(label("›", 24f, MUTED))
                return row
            }
        }
    }

    private fun play(channel: Channel) {
        try {
            if (player == null) {
                player = ExoPlayer.Builder(this).build()
                playerView.player = player
            }
            player?.setMediaItem(MediaItem.fromUri(channel.url))
            player?.prepare(); player?.play()
            status.text = "Reproduzindo: ${channel.name}"
        } catch (e: Exception) { toast("Não foi possível reproduzir: ${e.message}") }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        if (::playerView.isInitialized) playerView.player = null
        player?.release(); player = null
        io.shutdown()
        super.onDestroy()
    }
}
