# ADAILSON TECK TV

Aplicativo Android de IPTV com identidade visual própria, inspirado em interfaces modernas de streaming.

## Recursos
- Carregamento de listas M3U/M3U8.
- Acesso a canais ao vivo por Xtream Codes.
- Player integrado baseado em AndroidX Media3 / ExoPlayer, com suporte HLS.
- Busca de canais e filtros por categoria.
- Interface escura com cabeçalho, navegação por seções, painel de conexão e lista de canais.

## Compilar
Abra o projeto no Android Studio ou use o workflow de build configurado no repositório GitHub.

Use somente listas e credenciais de serviços que você tenha autorização para acessar. As abas de filmes e séries exibem aviso até que uma fonte VOD compatível seja configurada.
