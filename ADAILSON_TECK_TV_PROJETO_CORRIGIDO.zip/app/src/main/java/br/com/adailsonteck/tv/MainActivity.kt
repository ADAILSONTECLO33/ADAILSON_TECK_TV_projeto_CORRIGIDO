package org.adailson.br

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.net.URLEncoder
import java.util.concurrent.Executors

private const val BG = 0xFF080F1E.toInt()
private const val PANEL = 0xFF111D31.toInt()
private const val PANEL_2 = 0xFF17263D.toInt()
private const val ACCENT = 0xFF18A8E0.toInt()
private const val MUTED = 0xFF9EADC3.toInt()
private const val DEFAULT_M3U_URL = "https://raw.githubusercontent.com/BuddyChewChew/pluto/refs/heads/main/pluto_br.m3u"

 data class Channel(val name: String, val url: String, val group: String = "Canais")

class MainActivity : Activity() {
    private val client = OkHttpClient()
    private val io = Executors.newSingleThreadExecutor()
    private val channels = mutableListOf<Channel>()
    private var visibleChannels = listOf<Channel>()
    private lateinit var list: ListView
    private lateinit var status: TextView
    private lateinit var playerView: PlayerView
    private lateinit var mainRoot: LinearLayout
    private lateinit var playerHost: android.widget.FrameLayout
    private lateinit var playerPrompt: LinearLayout
    private lateinit var fullscreenButton: TextView
    private var playerHostIndex: Int = -1
    private var playerOriginalParams: android.view.ViewGroup.LayoutParams? = null
    private var isFullscreen = false
    private lateinit var search: EditText
    private lateinit var categoryBar: LinearLayout
    private lateinit var loginPanel: LinearLayout
    private var player: ExoPlayer? = null
    private var selectedGroup = "Todos"

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int = 12, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }
    private fun label(s: String, size: Float = 14f, color: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun field(hintText: String, password: Boolean = false) = EditText(this).apply {
        hint = hintText; setSingleLine(true); textSize = 14f
        setTextColor(Color.WHITE); setHintTextColor(MUTED)
        setPadding(dp(14), dp(11), dp(14), dp(11))
        background = rounded(PANEL_2, 9)
        if (password) inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
    }
    private fun actionButton(textValue: String, primary: Boolean = true, action: () -> Unit) = TextView(this).apply {
        text = textValue; textSize = 14f; gravity = Gravity.CENTER; setTypeface(typeface, Typeface.BOLD)
        setTextColor(Color.WHITE); setPadding(dp(16), dp(13), dp(16), dp(13))
        background = rounded(if (primary) ACCENT else PANEL_2, 9)
        setOnClickListener { action() }
    }
    private fun addGap(parent: LinearLayout, height: Int = 8) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        // Oculta as barras do Android também na tela principal em modo paisagem.
        // Isso evita que a barra lateral de navegação cubra a lista e os botões.
        hideSystemBars()

        mainRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(Color.BLACK)
        }
        val root = mainRoot

        // Cabeçalho compacto com a marca e ações.
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(3), dp(12), dp(7))
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(0xFF06122C.toInt(), 0xFF092A62.toInt(), 0xFF06122C.toInt()))
        }
        header.addView(label("☰", 27f, Color.WHITE, true).apply {
            setPadding(dp(5), dp(5), dp(5), dp(5))
            setOnClickListener { showSourceMenu() }
        })
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(15), 0, 0, 0) }
        brand.addView(label("👑  ADAILSON TECK TV", 22f, Color.WHITE, true))
        brand.addView(label("TV Online Sem Travar", 11f, 0xFFD7E5FF.toInt(), true))
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(label("⌕", 31f, Color.WHITE, true).apply {
            setOnClickListener { search.requestFocus() }
        })
        header.addView(label("⚙", 29f, Color.WHITE, true).apply {
            setPadding(dp(20), 0, 0, 0)
            setOnClickListener { showXtreamDialog() }
        })
        root.addView(header, LinearLayout.LayoutParams(-1, dp(66)))

        // Área principal: vídeo à esquerda e lista compacta à direita.
        val content = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val left = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, dp(6), 0)
        }
        playerHost = android.widget.FrameLayout(this).apply {
            background = rounded(Color.BLACK, 15, 0xFF08B8F4.toInt())
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }
        playerView = PlayerView(this).apply {
            layoutParams = android.widget.FrameLayout.LayoutParams(-1, -1)
            setBackgroundColor(Color.BLACK)
            useController = false
            resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
            background = rounded(Color.BLACK, 12)
        }
        playerHostIndex = 0
        playerOriginalParams = playerView.layoutParams
        playerHost.addView(playerView)
        // Toque no vídeo para abrir/fechar a reprodução em tela cheia.
        playerView.setOnClickListener {
            if (isFullscreen) exitFullscreen() else enterFullscreen()
        }
        playerPrompt = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        val playMark = TextView(this).apply {
            text = "▶"; gravity = Gravity.CENTER; textSize = 38f; setTextColor(Color.WHITE)
            background = rounded(0xFF07172B.toInt(), 60, 0xFF08B8F4.toInt())
        }
        playerPrompt.addView(playMark, LinearLayout.LayoutParams(dp(100), dp(100)))
        playerPrompt.addView(label("Selecione um canal para assistir", 17f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(16), 0, 0)
        })
        playerHost.addView(playerPrompt, android.widget.FrameLayout.LayoutParams(-1, -1))
        fullscreenButton = label("⛶", 25f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = rounded(0xCC07172B.toInt(), 30, 0xFF08B8F4.toInt())
            setPadding(dp(10), dp(5), dp(10), dp(5))
            visibility = View.GONE
            setOnClickListener { enterFullscreen() }
        }
        playerHost.addView(fullscreenButton, android.widget.FrameLayout.LayoutParams(
            dp(46), dp(46), Gravity.TOP or Gravity.END
        ).apply { topMargin = dp(10); marginEnd = dp(10) })
        left.addView(playerHost, LinearLayout.LayoutParams(-1, 0, 1f))
        status = label("Carregando canais...", 10f, MUTED)
        status.visibility = View.GONE
        content.addView(left, LinearLayout.LayoutParams(0, -1, 2.35f))

        val right = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(0xFF061329.toInt(), 15, 0xFF087ED0.toInt())
            setPadding(dp(9), dp(8), dp(9), dp(8))
        }
        right.addView(label("📺  CANAIS       »", 21f, Color.WHITE, true), LinearLayout.LayoutParams(-1, dp(42)))
        search = field("Buscar canal...")
        search.textSize = 15f
        search.setPadding(dp(12), dp(7), dp(12), dp(7))
        search.background = rounded(0xFF0B1D37.toInt(), 22, 0xFF087ED0.toInt())
        right.addView(search, LinearLayout.LayoutParams(-1, dp(46)))
        categoryBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val categoryScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(categoryBar)
        }
        right.addView(categoryScroll, LinearLayout.LayoutParams(-1, dp(48)))
        list = ListView(this).apply {
            divider = null
            isNestedScrollingEnabled = true
            setBackgroundColor(Color.TRANSPARENT)
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        }
        right.addView(list)
        content.addView(right, LinearLayout.LayoutParams(0, -1, 1.05f))
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))

        // Barra inferior no estilo da referência.
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        }
        val navItems = listOf("▣  TV AO VIVO", "▣  FILMES", "♜  SÉRIES", "★  FAVORITOS", "◷  HISTÓRICO")
        navItems.forEachIndexed { index, item ->
            val b = actionButton(item, index == 0) {
                when (index) {
                    0 -> status.text = "TV AO VIVO • ${channels.size} canais"
                    1 -> toast("Catálogo de filmes ainda não configurado.")
                    2 -> toast("Catálogo de séries ainda não configurado.")
                    3 -> toast("Favoritos será disponibilizado em uma próxima atualização.")
                    4 -> toast("Histórico será disponibilizado em uma próxima atualização.")
                }
            }
            b.textSize = 12f
            b.setPadding(dp(5), dp(11), dp(5), dp(11))
            b.background = rounded(if (index == 0) 0xFF08B8F4.toInt() else 0xFF0A2046.toInt(), 18,
                if (index == 0) 0xFF08B8F4.toInt() else 0xFF12539A.toInt())
            nav.addView(b, LinearLayout.LayoutParams(0, dp(58), 1f).apply {
                if (index > 0) leftMargin = dp(4)
            })
        }
        root.addView(nav, LinearLayout.LayoutParams(-1, dp(68)))

        list.setOnItemClickListener { _, _, position, _ ->
            if (position in visibleChannels.indices) play(visibleChannels[position])
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { filterChannels() }
            override fun afterTextChanged(s: Editable?) {}
        })
        setContentView(root)
        restoreSavedChannels()
        loadM3u(DEFAULT_M3U_URL)
    }

    private fun hideSystemBars() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
        )
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    private fun enterFullscreen() {
        if (isFullscreen) return
        val parent = playerView.parent as? android.view.ViewGroup ?: return
        parent.removeView(playerView)
        isFullscreen = true
        playerView.layoutParams = android.view.ViewGroup.LayoutParams(-1, -1)
        if (::fullscreenButton.isInitialized) fullscreenButton.visibility = View.GONE
        setContentView(playerView)
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        )
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
    }

    private fun exitFullscreen() {
        if (!isFullscreen) return
        val parent = playerView.parent as? android.view.ViewGroup
        parent?.removeView(playerView)
        playerView.layoutParams = playerOriginalParams
            ?: LinearLayout.LayoutParams(-1, dp(205))
        playerHost.addView(playerView, 0, playerOriginalParams ?: android.widget.FrameLayout.LayoutParams(-1, -1))
        if (::playerPrompt.isInitialized) {
            if (playerPrompt.parent == null) {
                playerHost.addView(playerPrompt, android.widget.FrameLayout.LayoutParams(-1, -1))
            }
            playerPrompt.visibility = if (player?.isPlaying == true) View.GONE else View.VISIBLE
        }
        if (::fullscreenButton.isInitialized) {
            if (fullscreenButton.parent == null) {
                playerHost.addView(fullscreenButton, android.widget.FrameLayout.LayoutParams(
                    dp(46), dp(46), Gravity.TOP or Gravity.END
                ).apply { topMargin = dp(10); marginEnd = dp(10) })
            }
            fullscreenButton.visibility = if (player?.isPlaying == true) View.VISIBLE else View.GONE
        }
        isFullscreen = false
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        setContentView(mainRoot)
        hideSystemBars()
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (isFullscreen) {
            exitFullscreen()
        } else {
            super.onBackPressed()
        }
    }

    private fun showTabMessage(tab: String) { status.text = "$tab selecionado" }

    // Menu simples: a lista M3U fica integrada e não aparece como uma opção de playlist.
    private fun showSourceMenu() {
        AlertDialog.Builder(this)
            .setTitle("ADAILSON TECK TV")
            .setItems(arrayOf("Atualizar canais M3U", "Conectar Xtream")) { _, which ->
                if (which == 0) loadM3u(DEFAULT_M3U_URL) else showXtreamDialog()
            }
            .setNegativeButton("Fechar", null)
            .show()
    }

    // Acesso ao Xtream pela engrenagem; os dados não são exibidos na tela principal.
    private fun showXtreamDialog() {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(8), dp(22), 0)
        }
        val serverField = field("Servidor (ex.: http://servidor:8080)")
        val userField = field("Usuário")
        val passField = field("Senha", true)
        panel.addView(serverField)
        addGap(panel, 10)
        panel.addView(userField)
        addGap(panel, 10)
        panel.addView(passField)

        val dialog = AlertDialog.Builder(this)
            .setTitle("Conectar Xtream")
            .setMessage("Informe os dados da sua assinatura.")
            .setView(panel)
            .setPositiveButton("Conectar", null)
            .setNegativeButton("Cancelar", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val server = serverField.text.toString().trim().trimEnd('/')
                val username = userField.text.toString().trim()
                val password = passField.text.toString()
                if (!(server.startsWith("http://") || server.startsWith("https://")) ||
                    username.isBlank() || password.isBlank()) {
                    toast("Confira servidor, usuário e senha.")
                    return@setOnClickListener
                }
                dialog.dismiss()
                loadXtream(server, username, password)
            }
        }
        dialog.show()
    }

    private fun loadM3u(url: String) {
        status.text = "Carregando lista M3U..."
        io.execute {
            try {
                val req = Request.Builder().url(url).build()
                client.newCall(req).execute().use { response ->
                    if (!response.isSuccessful) error("HTTP ${response.code}")
                    val body = response.body?.string() ?: error("Lista vazia")
                    val parsed = parseM3u(body)
                    runOnUiThread { showChannels(parsed, "M3U") }
                }
            } catch (e: Exception) { runOnUiThread { status.text = "Erro ao carregar M3U: ${e.message}" } }
        }
    }

    private fun parseM3u(text: String): List<Channel> {
        val out = mutableListOf<Channel>()
        var name = "Canal"; var group = "Canais"
        text.lineSequence().forEach { raw ->
            val line = raw.trim()
            if (line.startsWith("#EXTINF", true)) {
                name = line.substringAfterLast(",").trim().ifBlank { "Canal" }
                group = Regex("""group-title="([^"]*)"""").find(line)?.groupValues?.get(1) ?: "Canais"
            } else if (line.isNotBlank() && !line.startsWith("#") &&
                (line.startsWith("http://") || line.startsWith("https://"))) out.add(Channel(name, line, group))
        }
        return out
    }

    private fun loadXtream(server: String, username: String, password: String) {
        status.text = "Consultando canais Xtream..."
        io.execute {
            try {
                val u = URLEncoder.encode(username, "UTF-8")
                val p = URLEncoder.encode(password, "UTF-8")
                val base = "$server/player_api.php?username=$u&password=$p"
                val categoryNames = mutableMapOf<String, String>()
                // Alguns servidores enviam somente category_id na lista de canais.
                try {
                    val categoryReq = Request.Builder().url("$base&action=get_live_categories").build()
                    client.newCall(categoryReq).execute().use { categoryResponse ->
                        if (categoryResponse.isSuccessful) {
                            val categories = JSONArray(categoryResponse.body?.string() ?: "[]")
                            for (i in 0 until categories.length()) {
                                val category = categories.getJSONObject(i)
                                categoryNames[category.optString("category_id")] =
                                    category.optString("category_name", "TV ao vivo")
                            }
                        }
                    }
                } catch (_: Exception) { }
                val req = Request.Builder().url("$base&action=get_live_streams").build()
                client.newCall(req).execute().use { response ->
                    if (!response.isSuccessful) error("HTTP ${response.code}")
                    val arr = JSONArray(response.body?.string() ?: "[]")
                    val parsed = mutableListOf<Channel>()
                    for (i in 0 until arr.length()) {
                        val item = arr.getJSONObject(i)
                        val id = item.optString("stream_id")
                        val title = item.optString("name", "Canal")
                        val ext = item.optString("container_extension", "ts").ifBlank { "ts" }
                        val categoryId = item.optString("category_id")
                        val cat = item.optString("category_name",
                            categoryNames[categoryId] ?: "TV ao vivo")
                        parsed.add(Channel(title, "$server/live/$u/$p/$id.$ext", cat))
                    }
                    runOnUiThread { showChannels(parsed, "Xtream") }
                }
            } catch (e: Exception) { runOnUiThread { status.text = "Erro Xtream: ${e.message}" } }
        }
    }

    private fun showChannels(items: List<Channel>, source: String) {
        channels.clear(); channels.addAll(items)
        saveChannels(items)

        selectedGroup = "Todos"
        status.text = "$source • ${items.size} canais carregados"
        buildCategories()
        filterChannels()
    }


    // Guarda a lista carregada no armazenamento privado do aplicativo.
    // Assim os canais continuam disponíveis quando o app for fechado e aberto novamente.
    private fun saveChannels(items: List<Channel>) {
        try {
            val array = JSONArray()
            items.forEach { channel ->
                val obj = org.json.JSONObject()
                obj.put("name", channel.name)
                obj.put("url", channel.url)
                obj.put("group", channel.group)
                array.put(obj)
            }
            openFileOutput("saved_channels.json", MODE_PRIVATE).use { output ->
                output.write(array.toString().toByteArray(Charsets.UTF_8))
            }
        } catch (e: Exception) {
            if (::status.isInitialized) status.text = "Lista carregada, mas não foi possível salvar: ${e.message}"
        }
    }

    private fun restoreSavedChannels() {
        try {
            val file = getFileStreamPath("saved_channels.json")
            if (!file.exists()) return
            val content = openFileInput("saved_channels.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
            val array = JSONArray(content)
            val restored = mutableListOf<Channel>()
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                val name = item.optString("name")
                val url = item.optString("url")
                val group = item.optString("group", "Canais")
                if (name.isNotBlank() && url.isNotBlank()) restored.add(Channel(name, url, group))
            }
            if (restored.isNotEmpty()) showChannels(restored, "Lista salva")
        } catch (e: Exception) {
            status.text = "Não foi possível recuperar a lista salva: ${e.message}"
        }
    }

    private fun buildCategories() {
        categoryBar.removeAllViews()
        val groups = listOf("Todos") + channels.map { it.group }.distinct().filter { it.isNotBlank() }.sorted()
        groups.forEach { group ->
            val chip = TextView(this).apply {
                text = group; textSize = 13f; setTextColor(Color.WHITE)
                setPadding(dp(16), dp(10), dp(16), dp(10))
                background = rounded(if (group == selectedGroup) 0xFF08AEEF.toInt() else 0xFF10284B.toInt(), 22,
                    if (group == selectedGroup) 0xFF08AEEF.toInt() else 0xFF173D70.toInt())
                setOnClickListener { selectedGroup = group; buildCategories(); filterChannels() }
            }
            val lp = LinearLayout.LayoutParams(-2, -2); lp.rightMargin = dp(7)
            categoryBar.addView(chip, lp)
        }
    }

    private fun filterChannels() {
        val query = if (::search.isInitialized) search.text.toString().trim() else ""
        visibleChannels = channels.filter {
            (selectedGroup == "Todos" || it.group == selectedGroup) &&
                (query.isBlank() || it.name.contains(query, true))
        }
        if (!::list.isInitialized) return
        list.adapter = object : ArrayAdapter<Channel>(this, android.R.layout.simple_list_item_1, visibleChannels) {
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
                val item = getItem(position) ?: return TextView(this@MainActivity)
                val row = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(10), dp(12), dp(10), dp(12))
                    background = rounded(0xFF10213D.toInt(), 14)
                }
                val logo = TextView(this@MainActivity).apply {
                    text = "▶"; gravity = Gravity.CENTER; textSize = 19f; setTextColor(0xFF08B8F4.toInt())
                    background = rounded(0xFF07336C.toInt(), 40)
                }
                row.addView(logo, LinearLayout.LayoutParams(dp(32), dp(32)))
                val texts = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
                texts.addView(label(item.name, 13f, Color.WHITE, true))
                texts.addView(label(item.group, 10f, MUTED))
                row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
                row.addView(label("›", 24f, MUTED))
                return row
            }
        }
    }

    private fun play(channel: Channel) {
        try {
            if (player == null) {
                player = ExoPlayer.Builder(this).build()
                playerView.player = player
            }
            player?.setMediaItem(MediaItem.fromUri(channel.url))
            player?.prepare(); player?.play()
            if (::playerPrompt.isInitialized) playerPrompt.visibility = View.GONE
            if (::fullscreenButton.isInitialized) fullscreenButton.visibility = View.VISIBLE
            status.text = "Reproduzindo: ${channel.name}"
        } catch (e: Exception) { toast("Não foi possível reproduzir: ${e.message}") }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        if (::playerView.isInitialized) playerView.player = null
        player?.release(); player = null
        io.shutdown()
        super.onDestroy()
    }
}
