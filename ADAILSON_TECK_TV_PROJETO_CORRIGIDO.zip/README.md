# ADAILSON TECK TV

Aplicativo Android de TV ao vivo com player Media3/ExoPlayer.

## Recursos incluídos
- Lista M3U integrada, carregada automaticamente e sem exibir o endereço da lista na tela.
- Salvamento local dos canais carregados.
- Busca e filtro por categorias.
- Conexão Xtream pelo botão de configurações, com categorias ao vivo.
- Player em tela cheia: toque no vídeo para entrar ou sair; o botão Voltar também sai da tela cheia.
- Compatibilidade configurada para Android 5.0 (API 21) ou superior.
- Identificador do aplicativo: `org.adailson.br`.

## Gerar APK pelo GitHub
1. Envie o conteúdo desta pasta para a raiz de um repositório GitHub.
2. Abra a aba **Actions**.
3. Escolha **Gerar APK ADAILSON TECK TV** e toque em **Run workflow**.
4. Quando terminar, abra a execução e baixe o artefato **ADAILSON-TECK-TV-APK**.

O APK de depuração será `app-debug.apk`.
