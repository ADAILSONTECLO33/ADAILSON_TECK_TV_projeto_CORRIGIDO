# ADAILSON TECK TV

Projeto inicial Android para TV ao vivo com suporte a:
- URL de lista M3U
- Login Xtream Codes (servidor, usuário e senha)
- Reprodução HLS/HTTP compatível com Media3/ExoPlayer
- Layout escuro com identidade ADAILSON TECK
- Entrada Android TV (LEANBACK_LAUNCHER)

## Como gerar o APK

1. Instale Android Studio atualizado.
2. Abra a pasta `ADAILSON_TECK_TV`.
3. Aguarde a sincronização do Gradle.
4. Instale Android SDK Platform 35 e Android Build Tools sugeridos.
5. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. O APK de debug ficará em `app/build/outputs/apk/debug/app-debug.apk`.

## Observações importantes

- Este é um projeto inicial funcional, não um APK já compilado.
- Use somente URLs M3U e credenciais Xtream de serviços que você tem autorização para acessar.
- O app não inclui canais, filmes ou assinaturas.
- Alguns provedores usam formatos, cabeçalhos ou extensões próprios; pode ser necessário adaptar o player.
- Para publicar na Play Store, configure ícone, política de privacidade, assinatura e os requisitos atuais da loja.
- O app atualmente lista canais ao vivo. Categorias avançadas, filmes/séries Xtream, favoritos persistentes e controle parental são etapas seguintes.
