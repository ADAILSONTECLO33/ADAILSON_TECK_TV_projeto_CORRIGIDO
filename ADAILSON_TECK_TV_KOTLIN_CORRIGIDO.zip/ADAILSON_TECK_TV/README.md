# ADAILSON TECK TV

Projeto Android nativo em Kotlin com player Media3/ExoPlayer, carregamento de listas M3U e acesso Xtream Codes. Use somente listas e credenciais de serviços que você tem autorização para acessar.

## Gerar o APK pelo celular usando GitHub

1. Extraia este ZIP no celular.
2. Envie o conteúdo da pasta `ADAILSON_TECK_TV` para um repositório GitHub seu. A pasta `.github/workflows` precisa ser enviada também.
3. No GitHub, abra a aba **Actions**.
4. Selecione **Gerar APK Android** e toque em **Run workflow** (ou aguarde a compilação automática após enviar para `main`/`master`).
5. Quando terminar, abra a execução concluída e baixe o artefato **ADAILSON-TECK-TV-APK**.
6. Extraia o artefato e instale `app-debug.apk` no Android. Talvez seja necessário permitir a instalação pelo navegador/gerenciador de arquivos.

## Compilar localmente

Requer JDK 17 e Gradle 8.9. Execute `gradle assembleDebug` na pasta do projeto. O APK será criado em `app/build/outputs/apk/debug/app-debug.apk`.

## Recursos atuais

- Interface escura com identidade ADAILSON TECK.
- Player de TV ao vivo com controles Media3.
- Importação de listas M3U por URL.
- Conexão Xtream Codes.
- Busca e filtros por categoria.

Filmes e séries aparecem como áreas futuras: precisam de catálogo VOD/séries configurado para funcionar.
